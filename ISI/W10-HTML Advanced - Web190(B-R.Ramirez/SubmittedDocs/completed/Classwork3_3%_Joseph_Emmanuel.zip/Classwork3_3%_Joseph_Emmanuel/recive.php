<?php

$f = $_POST['username'];
$l = $_POST['password'];


echo "<h1> $f $l</h1>";