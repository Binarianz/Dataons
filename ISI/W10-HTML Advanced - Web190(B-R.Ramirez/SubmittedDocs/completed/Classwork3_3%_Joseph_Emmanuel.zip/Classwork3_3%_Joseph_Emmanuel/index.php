<?php
require "input.html";
?>