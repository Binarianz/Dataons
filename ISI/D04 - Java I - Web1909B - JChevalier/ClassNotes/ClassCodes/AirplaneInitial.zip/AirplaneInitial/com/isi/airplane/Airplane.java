package com.isi.airplane;

public class Airplane
{
	public boolean start()
	{
		System.out.println("Airplane starting");
		return true;
	}
	
	public boolean stop()
	{
		System.out.println("Airplane stopping");
		return true;
	}
	
	public boolean takeOff()
	{
		System.out.println("Airplane taking off");
		return true;
	}
	
	public boolean increaseAltitude()
	{
		System.out.println("Airplane increasing altitude");
		return true;
	}
	
	public boolean decreaseAltitude()
	{
		System.out.println("Airplane decreasing altitude");
		return true;
	}
}
