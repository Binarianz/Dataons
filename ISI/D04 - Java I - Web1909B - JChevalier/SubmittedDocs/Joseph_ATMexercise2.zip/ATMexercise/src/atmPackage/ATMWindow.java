package atmPackage;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class MyActionLister implements ActionListener{

@Override
public void actionPerformed(ActionEvent e) {

JButton btn =  (JButton) e.getSource();
System.out.println("This is My Button - "+btn.getText());
}
}


public class ATMWindow extends JFrame {

public JTextField balanceAmount;
// labels
public JLabel balanceLabel;
public JLabel balanceAmoutLabel;
public JLabel transactionsLabel;

// buttons
public JButton depositButton;
public JButton withdrawButton;
public JButton exitButton;


// panels
public JPanel balancePanel;
public JPanel balanceAmountPanel;
public JPanel balanceTextFieldPanel;
public JPanel depositeButtonPanel;
public JPanel withdrawButtonPanel;
public JPanel exitButtonPanel;


public JPanel contentPanel;

AccountClass account = new AccountClass("Joseph",3000);

public ATMWindow(String title) {
super(title);
createWindowElements();
createActions();
addComponentsToPanels();
addPanelsToContentPane();

// Packs your content
this.pack();
// Makes to move center of the screen
this.setLocationRelativeTo(null);
// this make you program on close
setDefaultCloseOperation(EXIT_ON_CLOSE);

}

private void createWindowElements() {

balanceAmount = new JTextField();

balanceAmoutLabel = new JLabel();
balanceAmoutLabel.setText("$"+account.getBalance());

balanceLabel = new JLabel();
balanceLabel.setText("Balance");
// buttons
depositButton = new JButton("Deposit");
withdrawButton = new JButton("Withdraw");
exitButton = new JButton();
exitButton.setText("Exit");

// panels
balancePanel = new JPanel();
balanceAmountPanel = new JPanel();
balanceTextFieldPanel  = new JPanel();
depositeButtonPanel  = new JPanel();
withdrawButtonPanel  = new JPanel();
exitButtonPanel  = new JPanel();

}

private void createActions() {
depositButton.addActionListener(new ActionListener() {

@Override
public void actionPerformed(ActionEvent event) {
// TODO Auto-generated method stub

//System.out.println("Deposit");
account.depositMoney(Double.parseDouble(balanceAmount.getText()));
balanceAmoutLabel.setText(String.valueOf(account.getBalance()));
balanceAmount.setText("");
}
});

withdrawButton.addActionListener( (ActionEvent event) -> {
//System.out.println("withDraw");
account.withdrawMoney(Double.parseDouble(balanceAmount.getText()));
balanceAmoutLabel.setText(String.valueOf(account.getBalance()));
});

MyActionLister myActionLister = new MyActionLister();
exitButton.addActionListener(myActionLister);

}

private void addComponentsToPanels() {
balancePanel.add(balanceLabel);
balancePanel.add(Box.createRigidArea(new Dimension(0, 20)));

balanceAmountPanel.add(balanceAmoutLabel);
balanceAmountPanel.add(Box.createRigidArea(new Dimension(0, 20)));

balanceTextFieldPanel.add(balanceAmount);
balanceTextFieldPanel.setLayout(new BoxLayout(balanceTextFieldPanel, BoxLayout.Y_AXIS));

depositeButtonPanel.add(depositButton);
depositeButtonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
depositeButtonPanel.setLayout(new BoxLayout(depositeButtonPanel, BoxLayout.Y_AXIS));

withdrawButtonPanel.add(withdrawButton);
withdrawButtonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
withdrawButtonPanel.setLayout(new BoxLayout(withdrawButtonPanel, BoxLayout.Y_AXIS));

exitButtonPanel.add(exitButton);
exitButtonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
exitButtonPanel.setLayout(new BoxLayout(exitButtonPanel, BoxLayout.Y_AXIS));

}

private void addPanelsToContentPane() {
contentPanel = (JPanel) this.getContentPane();
contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));


contentPanel.add(balancePanel);
contentPanel.add(balanceAmountPanel);
contentPanel.add(balanceTextFieldPanel);
contentPanel.add(depositeButtonPanel);
contentPanel.add(withdrawButtonPanel);
contentPanel.add(exitButtonPanel);
}
}