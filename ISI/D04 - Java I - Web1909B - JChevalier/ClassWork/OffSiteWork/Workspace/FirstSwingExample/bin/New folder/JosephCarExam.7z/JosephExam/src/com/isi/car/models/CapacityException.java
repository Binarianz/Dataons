package com.isi.car.models;

public class CapacityException extends Exception
{
	private static final long serialVersionUID = 1L;

	public CapacityException(double gasCapacity, double minCapacity, double maxCapacity)
	{
		// TODO
	}
}
