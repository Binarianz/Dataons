package com.isi.car.models;

public enum GasLevelState
{
	Empty, Partial, Full;
}
