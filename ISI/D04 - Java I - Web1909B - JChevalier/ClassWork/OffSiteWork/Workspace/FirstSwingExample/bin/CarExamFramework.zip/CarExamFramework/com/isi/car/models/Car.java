package com.isi.car.models;

import java.util.ArrayList;

import com.isi.car.interfaces.ICarListener;
import com.isi.car.interfaces.ICarModel;

public class Car implements ICarModel, Runnable
{	
	// Static constants

	public static final double MINIMUM_CAPACITY = 35;
	public static final double MAXIMUM_CAPACITY = 95;
	public static final double DRIVING_DELTA = -2.3d;
	public static final double FILLING_DELTA = 3.6d;


	// Instance variables

	private double gasLevel;
	private double gasCapacity;
	private GasLevelState gasLevelState;
	private CarState carState;
	
	private ArrayList<ICarListener> listenersList;

	
	// Getter methods
	// Implementation of ICarModel interface

	@Override
	public double getGasLevel() { return 0; }					// TODO
	@Override
	public double getGasCapacity() { return 0; }				// TODO
	@Override
	public GasLevelState getGasLevelState() { return null; }	// TODO
	@Override
	public CarState getCarState() {  return null; }				// TODO


	// Constructor

	public Car(double gasCapacity)
	{
		// TODO
	}


	// Public methods for adding/removing listeners
	
	public void addCarListener(ICarListener listener)
	{
		// TODO
	}

	public void removeCarListener(ICarListener listener)
	{
		// TODO
	}

	
	// Private setter methods for gas level and car state

	private synchronized void setGasLevel(double gasLevel)
	{
		// TODO
	}

	private synchronized void setCarState(CarState carState)
	{
		// TODO
	}
	
	
	// User action methods
	// Implementation of ICarModel interface

	@Override
	public void startDriving()
	{
		// TODO
	}

	@Override
	public void stopDriving()
	{
		// TODO
	}

	@Override
	public void startFillingGas()
	{
		// TODO
	}

	@Override
	public void stopFillingGas()
	{
		// TODO
	}


	// Thread method
	// Implementation of Runnable interface
	
	@Override
	public void run()
	{
		// TODO
	}
}
