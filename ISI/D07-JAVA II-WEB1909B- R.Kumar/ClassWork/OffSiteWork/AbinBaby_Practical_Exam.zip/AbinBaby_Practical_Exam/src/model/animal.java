package model;

public class animal {

}
