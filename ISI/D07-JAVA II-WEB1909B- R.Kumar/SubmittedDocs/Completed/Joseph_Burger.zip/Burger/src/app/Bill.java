package app;

public class Bill {

}