package com.isi;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class redirect
 */
@WebServlet("/redirect")
public class redirect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public redirect() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * int k=Integer.parseInt(request.getParameter("page")); PrintWriter
		 * pw=response.getWriter(); pw.println(k); response.sendRedirect("page1.jsp");
		 */
		
		String choice=request.getParameter("page");
		switch(choice) {
		case "1":
			   
			      request.getRequestDispatcher("/page1.jsp").forward(request, response);
			      break;
		
		case "2":

		      request.getRequestDispatcher("/page2.jsp").forward(request, response);
		      break;
		case "3":
		      request.getRequestDispatcher("/page3.jsp").forward(request, response);
		      break;
		case "4":
		      request.getRequestDispatcher("/page4.jsp").forward(request, response);
		      break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
