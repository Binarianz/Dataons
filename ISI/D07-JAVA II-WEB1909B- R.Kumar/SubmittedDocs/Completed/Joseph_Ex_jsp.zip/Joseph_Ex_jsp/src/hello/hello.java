package hello;

public class hello {

	public String poster()
	{
		return "Hello";
	}
}
