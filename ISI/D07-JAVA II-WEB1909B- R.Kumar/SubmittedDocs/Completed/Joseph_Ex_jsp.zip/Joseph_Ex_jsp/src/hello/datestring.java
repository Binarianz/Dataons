package hello;

import java.util.*;

public class datestring {
	public String getDate()
	{
		 Date date3=new Date();
		 return date3.toString();
	}
}
