package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginCookie
 */
@WebServlet("/LoginCookie")
public class LoginCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCookie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		
		String name = request.getParameter("name");
		String preference = request.getParameter("preference");
		
		Cookie cookie = null;
		Cookie cookies[] = request.getCookies();
		boolean isPresent = false;
		
		if(name!=null && preference!=null) {
			cookie = new Cookie("name", name);
			response.addCookie(cookie);
			cookie = new Cookie("preference", preference);
			
			writer.print("Welecome " + name + "&nbsp; if correct preferences are there, cookie with your name will be present!");
		}
		else if(name!=null && preference==null) {
			cookie = new Cookie("name", "");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			
			writer.print("Welcome " + name + "&nbsp; if correct preferences are there, cookie with your name will be present!");
		}
		else {
		if (cookies != null) {
			for(Cookie c : cookies) {
			if ("name".equals(c.getName())) {
				isPresent = true;
					writer.println("<html>" + 
							"<head>" + 
							"<meta charset=\"ISO-8859-1\">" + 
							"<title>Insert title here</title>" + 
							"</head>" + 
							"<body>" + 
							"<form action=\"LoginPageCookie\" method=\"get\">" + 
							"<h1>Login Page</h1>" + 
							"<label>Enter your name:</label>" + 
							"<input type=\"text\" name=\"name\" value=\"" + c.getValue() + "\">"+"<br>" + 
							"<label>Remember me:</label>" + 
							"<input type=\"checkbox\" name=\"preference\" value=\"ticked\" checked>" + 
							"<input type=\"submit\" value=\"submit\">" + 
							"</form>\r\n" + 
							"</body>\r\n" + 
							"</html>");
					break;
			}
			}
			if(!isPresent) {
				response.sendRedirect("index.html");
			}
		}	else
			{
				response.sendRedirect("index.html");
			}
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
