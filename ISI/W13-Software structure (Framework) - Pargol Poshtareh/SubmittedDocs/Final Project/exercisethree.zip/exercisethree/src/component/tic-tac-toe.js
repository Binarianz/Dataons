let count = 0
let player1 = 'X';
let player2 = 'O';

var currentPlayer = '';

function getWinner() {

    var box1 = document.getElementById("box1"),
        box2 = document.getElementById("box2"),
        box3 = document.getElementById("box3"),
        box4 = document.getElementById("box4"),
        box5 = document.getElementById("box5"),
        box6 = document.getElementById("box6"),
        box7 = document.getElementById("box7"),
        box8 = document.getElementById("box8"),
        box9 = document.getElementById("box9");

    //GETTING ALL POSSIBLITIES

    if (box1.innerHTML !== "" && box1.innerHTML === box2.innerHTML && box1.innerHTML === box3.innerHTML) {
       
        console.log(currentPlayer+"won the game")

    } else if (box4.innerHTML !== "" && box4.innerHTML === box5.innerHTML && box4.innerHTML === box6.innerHTML) {
        console.log("Winner");
        console.log(currentPlayer+"won the game")
       
    } else if (box7.innerHTML !== "" && box7.innerHTML === box8.innerHTML && box7.innerHTML === box9.innerHTML) {
        console.log("Winner");
        console.log(currentPlayer+"won the game")
       
    } else if (box1.innerHTML !== "" && box1.innerHTML === box4.innerHTML && box1.innerHTML === box7.innerHTML) {
        console.log("Winner");
        console.log(currentPlayer+"won the game")
        
    } else if (box2.innerHTML !== "" && box2.innerHTML === box5.innerHTML && box2.innerHTML === box8.innerHTML) {
        console.log("Winner");
        console.log(currentPlayer+"won the game")
        
    } else if (box3.innerHTML !== "" && box3.innerHTML === box6.innerHTML && box3.innerHTML === box9.innerHTML) {
        console.log("Winner");
        console.log(currentPlayer+"won the game")
        
    } else if (box1.innerHTML !== "" && box1.innerHTML === box5.innerHTML && box1.innerHTML === box9.innerHTML) {
        console.log("Winner");
        console.log(currentPlayer+"won the game")
        
    } else if (box3.innerHTML !== "" && box3.innerHTML === box5.innerHTML && box3.innerHTML === box7.innerHTML) {
        console.log("Winner");
        console.log(currentPlayer+"won the game")
       
    }
    // document.getElementById("winner").innerText=currentPlayer==='X'?this.
    

}
function printWinner(currentPlayer){
    console.log(currentPlayer+"won the game")
//     if(currentPlayer==='X'){
// document.getElementById("player1").style.visibility=true;
//     }else{
//         document.getElementById("player2").style.visibility=true;
//     }
}
// const wrapper = document.getElementById("main");
// wrapper.addEventListener("click", (event) => {
//     if (event.target.innerHTML != '') {
//         return
//     }
//     const trueButton = event.target.nodeName === "DIV";
//     if (!trueButton) {
//         return;
//     }
//     count++
//     clickingCard(event.target)
// });

function clickingCard(node) {
    currentPlayer = count % 2 === 0 ? player2 : player1;

    node.innerHTML = currentPlayer;
    getWinner();
}

document.getElementById('restartGame').onclick = function () {
    window.location.reload();
};