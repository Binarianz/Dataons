import React, { Component } from "react";
import ScriptTag from "react-script-tag";
class form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: "",
      lastName: "",
      email: "",
      sfirstName: "",
      slastName: "",
      semail: "",
    };
  }
  handleClick = () => {
    //do something
    // alert(this.state.firstName)
    console.log(this.state);
    var item = document.getElementById("old");

    item.parentNode.removeChild(item);
    document.getElementById("new").style.visibility = "visible";
  };

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };
  render() {
    return (
      <div id="maindiv">
        <div id="old">
          <div id="player1">
            <div className="container">
              <h1>Player 1</h1>
              <p>Please fill in this form</p>
              <hr />

              <label>
                <b>First Name</b>
              </label>
              <input
                type="text"
                placeholder="Enter First Name"
                name="firstName"
                id="fnamep1"
                required
                onChange={this.handleChange}
              />

              <label>
                <b>Last Name</b>
              </label>
              <input
                type="text"
                placeholder="Enter Last Name"
                name="lastName"
                id="lnamep1"
                required
                onChange={this.handleChange}
              />

              <label>
                <b>Email</b>
              </label>
              <input
                type="text"
                placeholder="Enter Email"
                name="email"
                id="emailp1"
                required
                onChange={this.handleChange}
              />

              <hr />
            </div>
          </div>

          <div id="player2">
            <div className="container">
              <h1>Player 2</h1>
              <p>Please fill in this form</p>
              <hr />

              <label>
                <b>First Name</b>
              </label>
              <input
                type="text"
                placeholder="Enter First Name"
                name="sfirstName"
                id="fnamep2"
                required
                onChange={this.handleChange}
              />

              <label>
                <b>Last Name</b>
              </label>
              <input
                type="text"
                placeholder="Enter Last Name"
                name="slastName"
                id="lnamep2"
                required
                onChange={this.handleChange}
              />

              <label>
                <b>Email</b>
              </label>
              <input
                type="text"
                placeholder="Enter Email"
                name="semail"
                id="emailp2"
                required
                onChange={this.handleChange}
              />
              <hr />
            </div>
          </div>
          <div className="clearfix">
            <button type="submit" id="registerbtn" onClick={this.handleClick}>
              Start
            </button>
          </div>
        </div>
        <div id="new" style={{ visibility: "hidden" }}>
          <section>
            <h1 className="gameTitle">TIC-TAC-TOE</h1>
            <div className="gameContainer" id="main">
              <div className="box" id="box1"></div>
              <div className="box" id="box2"></div>
              <div className="box" id="box3"></div>
              <div className="box" id="box4"></div>
              <div className="box" id="box5"></div>
              <div className="box" id="box6"></div>
              <div className="box" id="box7"></div>
              <div className="box" id="box8"></div>
              <div className="box" id="box9"></div>
            </div>
            <h1
              className="mainH1"
              id="player1"
              style={{ visibility: "hidden" }}
            >
              {this.state.firstName} won the game
            </h1>
            <h1
              className="mainH1"
              id="player2"
              style={{ visibility: "hidden" }}
            >
              {this.state.sfirstName} won the game
            </h1>
          </section>
        </div>
        <ScriptTag src="./tic-tac-toe.js"></ScriptTag>
      </div>
    );
  }
}
export default form;
