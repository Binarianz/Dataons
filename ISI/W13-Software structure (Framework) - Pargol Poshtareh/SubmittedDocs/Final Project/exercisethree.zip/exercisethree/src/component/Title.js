import React from "react";

export default function Title() {
  return (
    <div className="titleh1">
      <h1 className="mainH1">Welcome to Tic Tac Toe</h1>
    </div>
  );
}
