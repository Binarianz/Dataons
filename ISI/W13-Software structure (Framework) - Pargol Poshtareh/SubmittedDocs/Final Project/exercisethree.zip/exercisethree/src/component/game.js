// import React from 'react'

// export default function game() {
//     return (
//         <div>
            
//     <div id="mainHead">
//       <p>Player 1 has scored</p>
//     </div>
//     <div id="gameBoard">
//       <h1>Game Board</h1>
//       <br />
//       <button className="card" id="0"></button>
//       <button className="card" id="1"></button>
//       <button className="card" id="2"></button>
//       <button className="card" id="3"></button>
//       <button className="card" id="4"></button>
//       <button className="card" id="5"></button>
//       <button className="card" id="6"></button>
//       <button className="card" id="7"></button>
//       <button className="card" id="8"></button>
//     </div>
//     <div id="player2">
//       <p>Player 2 has scored</p>
//     </div>
//         </div>
//     )
// }
