#include <iostream>
using namespace std;
int main()
{
    int a, b, c;
    cout << "Enter three numbers\n";
    cin >> a >> b >> c;
    if (a < b && c < 5)
    {
        cout << "Hello\n";
    }
    system("pause");
    return 0;
}