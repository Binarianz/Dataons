#include <iostream>
using namespace std;
int main()
{
    float a;
    cout << "Enter one numbers\n";
    cin >> a;
    if (a > 1 && a < 3)
    {
        cout << "The number is between 1 and 3.\n";
    }
    system("pause");
    return 0;
}