#include <iostream>
#include <string>
using namespace std;
int main()
{
    int choice;
    cout << "\nMenu:\n~~~~~\n1) Play\n2) Exit\nPick your choice : ";

    system("pause");
}