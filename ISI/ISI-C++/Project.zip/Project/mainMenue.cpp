#include <iostream>
#include <string>
using namespace std;
int main()
{
    int choice;
    cout << "\nPick your choice : \n1) Play\n2) ";

    system("pause");
}