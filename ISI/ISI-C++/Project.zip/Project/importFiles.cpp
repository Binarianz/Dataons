#include <iostream>
#include<fstream>
#include<string>
#include<time.h>
using namespace std;
int main()
{
    
    system("pause");
}