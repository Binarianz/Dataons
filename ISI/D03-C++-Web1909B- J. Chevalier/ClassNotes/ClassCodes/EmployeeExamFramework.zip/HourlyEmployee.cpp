#include "HourlyEmployee.h"
using namespace std;

// Private method

void HourlyEmployee::setHourlyWage(double hourlyWage)
{

}


// Public methods

HourlyEmployee::HourlyEmployee(string name, string jobTitle, double hourlyWage)
{

}

double HourlyEmployee::getHourlyWage()
{

}

double HourlyEmployee::getHoursPaid()
{

}

// Virtual override method
bool HourlyEmployee::payEmployee()
{

}

// Virtual override method
bool HourlyEmployee::giveEmployeeRaise(double percentage)
{

}

// Virtual override method
string HourlyEmployee::getStatusString()
{

}
