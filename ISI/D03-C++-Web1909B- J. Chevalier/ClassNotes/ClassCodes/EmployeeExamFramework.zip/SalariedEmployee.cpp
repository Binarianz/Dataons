#include "SalariedEmployee.h"
using namespace std;

// Private method

void SalariedEmployee::setYearlySalary(double yearlySalary)
{

}


// Public methods

SalariedEmployee::SalariedEmployee(string name, string jobTitle, double yearlySalary)
{

}

double SalariedEmployee::getYearlySalary()
{

}

int SalariedEmployee::getDaysPaid()
{

}

double SalariedEmployee::getDailySalary()
{

}

// Virtual override method
bool SalariedEmployee::payEmployee()
{

}

// Virtual override method
bool SalariedEmployee::giveEmployeeRaise(double percentage)
{
	
}

// Virtual override method
string SalariedEmployee::getStatusString()
{

}
