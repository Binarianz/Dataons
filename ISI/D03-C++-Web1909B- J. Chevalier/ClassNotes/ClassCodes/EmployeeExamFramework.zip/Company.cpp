#include "Company.h"
using namespace std;

// Private method

void Company::increaseArrayMaxCapacity(int newArrayMaxCapacity)
{

}


// Public methods

Company::Company()
{

}

Company::~Company()
{

}

int Company::getEmployeesCount()
{
	
}

Employee* Company::getEmployee(int index)
{
	
}

int Company::findEmployeeIndex(string name)
{

}

int Company::findEmployeeIndex(int id)
{

}

void Company::addEmployee(Employee* employee)
{

}

bool Company::removeEmployee(int index)
{

}

string Company::toString()
{

}
