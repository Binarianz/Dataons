#include "Employee.h"
using namespace std;

// Static fields



// Static calculated getter methods

double Employee::getMinimumYearlyIncome()
{
	
}

double Employee::getMaximumHourlyIncome()
{
	
}


// Protected setter method

void Employee::setPaymentReceived(double paymentReceived)
{
	
}


// Public methods

Employee::Employee(string name, string jobTitle)
{

}

Employee::~Employee()
{

}

int Employee::getId()
{

}

string Employee::getName()
{

}

string Employee::getJobTitle()
{

}

int Employee::getDaysWorked()
{

}

double Employee::getHoursWorked()
{

}

double Employee::getPaymentReceived()
{

}

Date* Employee::getDateLastPaid()
{

}

bool Employee::logEmployeeHours(double totalHours, int totalDays)
{

}

string Employee::toString()
{
	
}

// Virtual parent method
string Employee::getStatusString()
{

}
