#include<iostream>
#include<string>
#include"TravellingMerchant.h"
using namespace std;

int main() {
	/*TravellingMerchant merchants;

	merchants.startGame();*/

	cin.get();
	return 1;
}