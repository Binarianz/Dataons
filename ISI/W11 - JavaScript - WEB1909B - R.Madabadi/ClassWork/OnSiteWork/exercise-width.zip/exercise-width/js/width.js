$.elements = $('#targets').children()
$($.elements.eq(0)).click(function () {
    $.elements.eq(0).html('<div class="prop">' + $.elements.eq(0).width().toFixed(2) + '</div>')
    classCss()
})
$($.elements.eq(1)).click(function () {
    $.elements.eq(1).html('<div class="prop">' + $.elements.eq(1).width().toFixed(2) + '</div>')
    classCss()
})
$($.elements.eq(2)).click(function () {
    $.elements.eq(2).html('<div class="prop">' + $.elements.eq(2).width().toFixed(2) + '</div>')
    classCss()
})
$($.elements.eq(3)).click(function () {
    $.elements.eq(3).html('<div class="prop">' + $.elements.eq(3).width().toFixed(2) + '</div>')
    classCss()
})
$($.elements.eq(4)).click(function () {
    $.elements.eq(4).html('<div class="prop">' + $.elements.eq(4).width().toFixed(2) + '</div>')
    classCss()
})
function classCss () {
    $('.prop').css({
        border: '#0000aa solid',
        width: '50px',
        'background-color': 'rgb(192, 192, 235)',
        'border-radius': '40px'
    })
}
