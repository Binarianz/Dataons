'use strict'

const temperature = 21.3
const fruits = ['apple', 'pear', 'orange']
console.log('Yo.')
console.log(temperature)
console.log(fruits)
console.log('the temparature is ', temperature)
console.log('The collection of fruits is ', fruits)
console.log('<h1> no html interpreter<h1>')
console.log(18, 'eighteen', true, null)
console.log('This is a group')
console.log('\t Group content')
console.log('This is a second group(closed by default)')
console.log('\t content of second group')
