function execute (opertor, x, y) {
    switch (opertor) {
    case 'ADD':
        return x + y
    case 'SUB':
        return x - y
    case 'MUL':
        return x * y
    case 'chaloupe':
        return 'unknown operation name...'
    case 666:
        return 'Unknown operation type...'
    case div:
        return (div(x, y))
    }
}
