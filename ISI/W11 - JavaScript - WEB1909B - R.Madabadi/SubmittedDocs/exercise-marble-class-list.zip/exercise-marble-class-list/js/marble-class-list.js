const targetDiv = document.getElementById('container').querySelectorAll('div')
targetDiv[0].className += ' rounded'
targetDiv[1].className += ' orange size_x'
targetDiv[2].className += ' size_xx incline'
targetDiv[3].className += ' rounded purple offset'
targetDiv[4].className += ' rounded purple size_xxx'
console.log(targetDiv)
