#include"ConsoleInput.h"
//#include"StringConversions.h"
#include<iostream>
#include<string>