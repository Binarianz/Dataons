#include"ConsoleInputTest.h"
#include<iostream>
#include<string>