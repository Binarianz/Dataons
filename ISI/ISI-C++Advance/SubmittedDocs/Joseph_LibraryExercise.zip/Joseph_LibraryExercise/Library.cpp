#include "Library.h"
using namespace std;

void Library::expandArray(int maxItemsCount)
{
	cout << "TODO:  Library::expandArray(int maxItemsCount)" << endl;
}

Library::Library()
{
	
	//cout << "TODO:  Library() default constructor" << endl;
}

Library::~Library()
{
	cout << "TODO:  ~Library() destructor" << endl;
}

LibraryItem* Library::getItem(int index)
{
	cout << "TODO:  Library::getItem(int index)" << endl;
	return nullptr;
}

int Library::getItemsCount()
{
	return itemsCount;
}

int Library::getMaxItemsCount()
{
	return maxItemsCount;
}

int Library::getBorrowedCount()
{
	//return borr;
}

int Library::getItemIndex(int referenceNumber)
{
	cout << "TODO:  Library::getItemIndex(int referenceNumber)" << endl;
	return 0;
}

int Library::getItemIndex(string title)
{
	cout << "TODO:  Library::getItemIndex(string title)" << endl;
	return 0;
}

void Library::addItem(LibraryItem* item)
{
	cout << "TODO:  Library::addItem(LibraryItem* item)" << endl;
}

bool Library::removeItem(int index)
{
	cout << "TODO:  Library::removeItem(int index)" << endl;
	return false;
}

string Library::toString()
{
	cout << "TODO:  Library::toString()" << endl;
	return "";
}

void Library::display()
{
	cout << "TODO:  Library::display()" << endl;
}
