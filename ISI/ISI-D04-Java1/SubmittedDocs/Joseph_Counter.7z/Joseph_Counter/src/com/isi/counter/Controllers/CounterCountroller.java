package com.isi.counter.Controllers;

import com.isi.counter.Models.Counter;
import com.isi.counter.views.CounterWindow;

public class CounterCountroller {

	private Counter counter;
	private CounterWindow window;
	public CounterCountroller(Counter counter,CounterWindow window) {
		this.counter=counter;
		this.window=window;
	}
	public void increment() {

	}
	public void decrement() {

	}
	public void random() {

	}
}