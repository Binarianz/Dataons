function changeColor(newColor, bkColor, bdColor, newFont, newSize, newPlace) {
  var elem = document.getElementById('test');
  elem.style.color = newColor;
  elem.style.backgroundColor = bkColor;
  elem.style.border = bdColor;
  elem.style.fontFamily = newFont;
  elem.style.fontSize = newSize;
  elem.style.textAlign = newPlace
}