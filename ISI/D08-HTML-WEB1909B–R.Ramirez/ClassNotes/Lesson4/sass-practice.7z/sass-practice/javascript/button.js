function changeColor(newColor){
    var elem = document.getElementById('test');
    elem.style.color = newColor;
}