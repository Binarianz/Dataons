<?php 


$firsth1="Great Ways to Show Your Services";
$des="This should be used to tell a story and let your users know a little more about your product or service. How can you benefit them?";
$video="Watch Overview<br>Video in 40 Second...";
$free="<h3 class='title'>Start Your Free Trial</h3>
<p>Supporting Call to Action Goes Here</p>";
$name="<label for='cs2Name'>Your Name *</label>";
$email="<label for='cs2Email'>Your Email *</label>";
$phone="<label for='cs2PhoneNum'>Phone Number *</label>";
$trust=" Trusted by the world’s most innovative businesses – big and small";
$some="Some Features";
$create="Create a Beautiful Landing Page In a Minute Not Weeks";
$new="New Design";
$news="This should be used to tell a story and let your users know a little more about your product and service.";
$our="Our Services";
$ourh2="We Provide The Solutions To Grow Your Business";
$outp="This should be used to tell a story about your product or service. How can you benefit them?";
$brand="Branding";
$andro="Android App";
$hot="HOT";
$dev="Developing";
$analytic="Analytics";
$psome=" This should be used to tell a story about your product or service. How can you benefit them?";
$joinnow1="Join Now! Don’t Miss The Special Offer ";
$discount="50% Discount";
$dispara="This should be used to tell a story and let your users know a little more about your product or service. How can
you benefit them?";
$mtitle="Magicay";
$oaddress="Our Address";
$fmail="ExplicitConcepts@Envato.com";
$f2mail="Morad@Market.com";
$trademark="2018 - 2019 ©";
$trademark2=". All Rights Reserved.";
$morad="Morad";
