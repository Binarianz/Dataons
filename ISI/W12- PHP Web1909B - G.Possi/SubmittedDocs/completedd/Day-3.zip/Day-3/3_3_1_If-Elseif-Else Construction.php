<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<form method="post" action="3_3_2_If-Elseif-Else Construction.php">
        <h2>Days of the week</h2>
        <label for="fname">Please enter a day of the week:</label><br>
        <input type="text" name="dayName"><br><br>
        <button type="submit" value="submit">Go</button>
    </form>
</body>
</html>