<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="3_1_2Simple Form with PHP Response.php" method="post">
        <h2>Favorite City</h2>
        <label for="fname">Please enter your favorute city:</label><br>
        <input type="text" name="cityName"><br><br>
        <button type="submit" value="submit">Go</button>
    </form>
</body>
</html>