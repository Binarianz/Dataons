<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <h1>Day 3 - Global Variables and Form Handling PHP Global Variables and Form HandlingFile</h1>
    <ol>
        <li><a href="3_1_1Simple Form with PHP Response.php">Exercise-3_1: Simple Form with PHP Response.php</a></li><br>
        <li><a href="3_2_Interactive Form with If-Else Statement.php">Exercise-3_2: Interactive Form with If-Else Statement</a></li><br>
        <li><a href="3_3_1_If-Elseif-Else Construction.php">Exercise-3_3: If-Elseif-Else Construction</a></li><br>
        <li><a href="3_4_1_Switch Statement.php">Exercise-3_4: Switch Statement</a></li><br>
        <li><a href="app.question_joseph_emmanuel/index.php">app.question</a></li><br>
    </ol>
</body>
</html>