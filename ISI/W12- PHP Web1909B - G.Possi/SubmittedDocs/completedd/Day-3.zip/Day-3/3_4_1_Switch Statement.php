<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Pick a Day</h1>
    <form action="3_4_2_Switch Statement.php" method="post">
        <label for="fname">Please choose a day:</label><br><br>
        <select name="dayName">
            <option value="Monday">Monday</option>
            <option value="Tuesday">Tuesday</option>
            <option value="Wednesday">Wednesday</option>
            <option value="Thursday">Thursday</option>
            <option value="Friday">Friday</option>
            <option value="Saturday">Saturday</option>
        </select><br><br>
        <button type="submit" value="submit">Go</button>
    </form>
</body>
</html>

