<?php
    $x=5;
    $y=10;
    echo "Added value is: ".$x+$y;
?>