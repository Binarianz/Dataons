<?php
    $txt ="Hello";
    echo "created $txt veriable and printing...... :".$txt;
?>