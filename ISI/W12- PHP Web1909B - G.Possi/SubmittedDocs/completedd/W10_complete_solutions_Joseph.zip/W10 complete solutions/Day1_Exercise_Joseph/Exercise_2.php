<!DOCTYPE html>
<html>
<body>
<?php
    echo "This is PHP";
?>
</body>
</html>