<!DOCTYPE html>
<html>
<body>
<?php
/*This is a
multi-line
comment*/
echo "created a multi line comment: c the code"
?>
</body>
</html>
