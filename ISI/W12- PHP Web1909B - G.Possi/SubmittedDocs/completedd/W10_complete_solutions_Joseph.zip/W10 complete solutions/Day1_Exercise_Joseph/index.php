<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
<h1>Day 1 - Installation and Introduction</h1>
    <ol>
    <a href="#"></a>
    <li>Exercise_1 :<br><a href="Exercise_1.php">Answer</a></li><br>
    <li>Exercise_2 :<br><a href="Exercise_2.php">Answer</a></li><br>
    <li>Exercise_3 :<br><a href="Exercise_3.php">Answer</a></li><br>
    <li>Exercise_4 :<br><a href="Exercise_4.php">Answer</a></li><br>
    <li>Exercise_5 :<br><a href="Exercise_5.php">Answer</a></li><br>
    <li>Exercise_6 :<br><a href="Exercise_6.php">Answer</a></li><br>
    <li>Exercise_7 :<br><a href="Exercise_7.php">Answer</a></li><br>
    </ol>
</body>
</html>