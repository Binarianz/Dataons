<!DOCTYPE html>
<html>
<body>
<?php
// This is a single-line comment
echo "created a single line comment: c the code"
?>
</body>
</html>
