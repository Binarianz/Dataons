<!DOCTYPE html>
<html>
<body>
<?php
echo "Hello World";
?>
</body> 	
</html>