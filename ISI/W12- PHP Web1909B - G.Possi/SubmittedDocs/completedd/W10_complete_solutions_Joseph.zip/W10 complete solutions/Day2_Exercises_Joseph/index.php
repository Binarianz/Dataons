<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <h1>Day 2 - PHP Data Types, Arrays and Control Structures</h1>
    <ol>
        <li><a href="2_1_String_exercise_Joseph.php">Exercise-2_1-PHP Strings Page</a></li><br>
        <li><a href="2_2_Operators_Joseph.php">Exercise-2_2-PHP Operators Page</a></li><br>
        <li><a href="2_3_ifelse_Joseph.php">Exercise-2_3-PHP if else Page</a></li><br>
        <li><a href="2_4_switch_Joseph.php">Exercise-2_4-PHP switch Statement Page</a></li><br>
        <li><a href="2_5_Loops_Joseph.php">Exercise-2_5-PHP Loops Page</a></li><br>
        <li><a href="2_6-PHP Functions_Joseph.php">Exercise-2_6-PHP Functions Page</a></li><br>
        <li><a href="2_7-PHP Arrays_Joseph.php">Exercise-2_7-PHP Arrays Page</a></li><br>
        <li><a href="exercise-first-page-lastName-firstName.php">Exercise - First Page</a></li><br>
        <li><a href="exercise-string-manipulation_lastName-firstName.php">Exercise - String ManipulationPage</a></li><br>
    </ol>
</body>
</html>