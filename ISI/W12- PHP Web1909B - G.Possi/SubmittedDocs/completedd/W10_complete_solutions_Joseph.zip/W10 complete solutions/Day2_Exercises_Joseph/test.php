<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $x=5985;
    var_dump(is_numeric($x));
    echo "<br>";

    $y="5985";
    var_dump(is_numeric($y));
    echo "<br>";

    $z="59.85";
    var_dump(is_numeric($z));
    echo "<br>";

    $w="hello";
    var_dump(is_numeric($w));
    echo "<br>";
    ?>
</body>
</html>