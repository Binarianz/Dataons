
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>W10 complete solutions</h1>
    <ul>
        <li><a href="Day1_Exercise_Joseph/index.php">Day-1</a></li>
        <li><a href="Day2_Exercises_Joseph/index.php">Day-2</a></li>
    </ul>
</body>
</html>