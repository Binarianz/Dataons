﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JosephEmmanuel
{
    class Program
    {
        static string  firstName;
        static void Main(string[] args)
        {
            #region Question 1
            //Console.WriteLine("Hello World "); //Inbulilt function to print message to the console in a line, next message will be printed in next line.
            #endregion
            #region Question 2
            // DisplayMessage("Hello World");
            #endregion
            #region Question 3
            //firstName = GetStringFromUser();
            // DisplayMessage(firstName);
            #endregion
            #region Question 4
            //firstName = GetStringFromUser("Please enter your first name");
            //DisplayMessage(firstName);
            #endregion
            #region Question 5
            // GetStringFromUser(15, "Please enter a name no longer than 15 characters");
            #endregion
            #region Question 6
            //GetStringFromUser(2,12,"Please enter a name between 2 and 12 characters long");
            #endregion
            #region Question 7
            //GetUserInt("Enter an intiger");
            #endregion
            #region Question 8
            //int[] k = new int[5];
            //k = MakeUserIntArray(5);
            //for (int i = 0; i < 5; i++)
            //{
            //    Console.WriteLine(k[i]);
            //}
            #endregion
            #region Question 9
            /*            string [] k = new string[5];
                        k = MakeUserStringArray(5);
                        for (int i = 0; i < 5; i++)
                        {
                            Console.WriteLine(k[i]);
                        }*/
            #endregion
            #region Question 10
            //Console.WriteLine(CheckIfPrime(4)); 
            #endregion
            #region Question 11
            //PrintAllPrimesBelow(GetUserInt("Enter an intiger"));
            #endregion
            #region Question 12
            //Console.WriteLine(ConcatenateStrings(MakeUserStringArray(GetUserInt("Please enter the string array size"))));            
            #endregion
            #region Question 13
            // Console.WriteLine((CompareIntArrays(MakeUserIntArray(GetUserInt("Enter the size of First Integer array")), MakeUserIntArray(GetUserInt("Enter the size of Second Integer array"))))?"Arrays are same":"Arrays are not same");
            #endregion
            #region Question 14
            //Console.WriteLine("The result of factorial calculation is : "+Factorial(GetUserInt("Enter the number to calculate factorial")));
            #endregion
            Console.ReadKey();
        }
        #region Question 2
        static void DisplayMessage(string  message)// function to print message which takes one string  as a parameter value(message) and write it to the console.
        {
            Console.WriteLine(message);
        }
        #endregion
        #region Question 3
        static string GetStringFromUser() //returning a string that recived from the user.
        {
            return Console.ReadLine();//it's a built in function that takes returns next line of characters fro input stream or null if there is no input string from the user.
        }
        #endregion
        #region Question 4
        static string GetStringFromUser(string message)
        {
            DisplayMessage(message);//calling the print function for the string message.
            return Console.ReadLine();//then returning the string reciveed from the console.
        }
        #endregion
        #region Question 5
        static string GetStringFromUser(int maxLength,string message)
        {
            DisplayMessage(message);//calling the print function for the string message.
            firstName = Console.ReadLine();//reading the string from console.
            while (firstName.Length>maxLength)//while loop run untill a valid input is given by the user.
            {
                DisplayMessage("Re-Enter the string, maximum allowed length is "+maxLength);//error message asking the user to input a valid string with a size of less than maxLength.
                firstName = Console.ReadLine();//reading the input
            }
            return firstName;//returning the input given by the user which obay the condotion.
        }
        #endregion
        #region Question 6
        static string GetStringFromUser(int minLength,int maxLength, string message)
        {
            do
            {
                DisplayMessage(message);//displaying the message to entter the value,it will minmum run this line one time
                firstName = Console.ReadLine();//reading the input from the user also runs one time minimum
            } while (firstName.Length > maxLength|| firstName.Length < minLength); //codition with one OR condtion to check that the given value is NOT between specified range
            return firstName;//returning the input given by the user which obay both min and max condotions.
        }
        #endregion
        #region Question 7
        static int GetUserInt(string messageString)// function defenition start
        {
            int userInt;//Local variable userint for returning the output
            bool status;//local boolean variable to hold condtion value
            do
            {
               status= Int32.TryParse(GetStringFromUser(messageString), out userInt);//using the try parse method to check if we can parse the string.
            } while (status== false);//condition check for the while loop.
            return userInt;//returning the first true value.
        }
        #endregion
        #region Question 8
        static int[] MakeUserIntArray(int arrySize)
        {
            int[] userArray = new int[arrySize];//creating a new array to store user inout array.
            for (int i = 0; i < arrySize; i++)
            {
                userArray[i] = GetUserInt("Please enter the element at position " +i.ToString());//adding elements to the array by calling getuserInt function.
            }
            return userArray;//returning the complete array
        }
        #endregion
        #region Question 9
        static string[] MakeUserStringArray(int arraySize)
        {
            string[] userStringArray = new string[arraySize];//creating a new string arry to hold user input
            for (int i = 0; i < arraySize; i++)
            {
                userStringArray[i] = GetStringFromUser("Please enter the string element in postion " + i);//adding elements to array
            }
            return userStringArray;//returning the array
        }
        #endregion
        #region Question 10
        static bool CheckIfPrime(int numberToCheck)
        {
           bool answer=true;//creating a new boolean element to hold return value
            for (int i = 2; i <= numberToCheck/2; i++)//checking from 2 to half of the the passed value becouse only the number till half of passed value can divide the number equaly.
            {               
                if (numberToCheck % i == 0)//checking if it is divisible by i got from the above gor loop.
                {
                    answer = false;//if divisible then it is not a prime number
                    break;//getting out of if and for loop.
                }
            }                
            return answer;//returning the answer.
        }
        #endregion
        #region Question 11
        static void PrintAllPrimesBelow(int numberToPrime)
        {
            for (int i = numberToPrime; i >= 2; i--)//starting from top to the last number, which is equal to 2.
/*
 * there are two ternary operators.
                                    1) for checking the number is prime by calling the previous functionif true then write i to the console else write empty string to the console..
                                    2) for adding the ", " to the string , if the prime number is last digit that is 2 then it won't add the ", " string to the existing string else it will add it to the string.
 */
                Console.Write(CheckIfPrime(i)==true ? i.ToString()+(i!=2?", ":string.Empty):string.Empty);//writes the output to the console from the nested ternary operators.
        }
        #endregion
        #region Question 12
        static string ConcatenateStrings(string[] stringToConcatenate)
        {
            string answerString=string.Empty;//initializing string with empty string.
            for (int i = 0; i < stringToConcatenate.Length; i++)
                answerString += stringToConcatenate[i] + (i==stringToConcatenate.Length-1||stringToConcatenate[i]==string.Empty?string.Empty:", ");
            /*adding each elements from the passed string to the string inside function scope. ternary operator to add ", " with two condtions,
                   1)should't be the last element of the array string.
                   2)The string should not be empty .
               else there will be unnecessary ", " in the console output.
             */
            return answerString;//returniing answer from the function.
        }
        #endregion
        #region Question 13
        static bool CompareIntArrays(int[] array1,int[] array2)
        {
            bool isSameArray = false;//creating a boolean variable thinking initially arrays are not same.
            if (array1.Length == array2.Length)//only need to continue inside if arrays are of same length.
            {
                for (int i = 0; i < array1.Length; i++)//if lengths are same then we check if all the elements are same.
                    isSameArray = array1[i] == array2[i] ? true : false;//if they are same elements then the boolean variable will assign true else it will be false.
            }
            return isSameArray;//returning the answer variable.
        }
        #endregion
        #region Question 14
        static int Factorial(int userInput)
        {
            int result=1;//creating an intiger variable and assigning it to one. 
            for (int i = 2; i <= userInput; i++)//starting from 2 till maximum which is user input,becouse we already assigned result=1, also mutiplying 1 won't change the result.
                result *= i;//multiplying and storing the value to result with result.
            return result;//returning result to the call.
        }
        #endregion
    }
}
